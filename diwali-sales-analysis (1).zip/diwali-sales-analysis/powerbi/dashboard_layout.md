# Dashboard Layout — 5-Page Diwali Sales Dashboard

Suggested layout for a professional, story-led Power BI report. Grid: 1280 × 720 px per page (16:9). Uses the palette from `diwali_theme.json`.

---

## Global Elements (on every page)

- **Page header strip** (top, height ~60px):
  - Left: Report title *"Diwali Sales Dashboard"* + brand mark.
  - Right: page navigation buttons (Executive · Demographics · Geography · Products · Segments).
- **Global slicer bar** (right rail, width ~220px):
  - `zone`, `state`, `gender`, `age_group`, `product_category`, `revenue_bucket`.
  - Set to *sync slicers* across all pages.
- **Footer:** last refresh timestamp + "Data source: internal Diwali sales feed".

---

## Page 1 — Executive Summary

**Goal:** Board-level snapshot answering *"How did Diwali go?"* in 5 seconds.

| Slot | Visual | Field / Measure |
|---|---|---|
| Row 1 (four KPI cards) | Card | `[Revenue (Cr)]`, `[Total Orders]`, `[Unique Customers]`, `[AOV Formatted]` |
| Row 2 left | Donut | `zone` × `[Total Revenue]` |
| Row 2 centre | Horizontal bar | Top 10 states via `[Top 10 State Revenue]` |
| Row 2 right | Column chart | `age_group` × `[Total Revenue]` (sorted using `age_group_sort`) |
| Row 3 | Ribbon or stacked column | `product_category` × `[Total Revenue]` broken down by `gender` |

---

## Page 2 — Customer Demographics

**Goal:** *Who* buys during Diwali?

| Slot | Visual | Field / Measure |
|---|---|---|
| KPI row | Cards | `[Female Revenue %]`, `[Married Revenue %]`, `[Revenue Per Customer]` |
| Left | Donut | `gender` × `[Total Revenue]` |
| Centre | Clustered column | `age_group` × `[Total Revenue]` split by `gender` |
| Right | 100% stacked bar | `age_group` × `marital_status_label` |
| Bottom | Treemap | `occupation` × `[Total Revenue]` |

---

## Page 3 — Geography

**Goal:** *Where* do buyers live?

| Slot | Visual | Field / Measure |
|---|---|---|
| Left large | Filled Map (India) | `state` × `[Total Revenue]` — colour scale from theme |
| Right top | Horizontal bar | Top 10 states via `[Top 10 State Revenue]` |
| Right middle | Donut | `zone` × `[Total Revenue]` |
| Right bottom | Table | `state`, `[Total Orders]`, `[Total Revenue]`, `[Average Order Value (AOV)]`, `[State Rank]` |

---

## Page 4 — Products

**Goal:** *What* do buyers buy?

| Slot | Visual | Field / Measure |
|---|---|---|
| KPI row | Cards | `[Average Order Value (AOV)]`, `[Total Orders]` |
| Left | Horizontal bar | `product_category` × `[Total Revenue]` |
| Right top | Column | `product_category` × `[Total Orders]` |
| Right bottom | Table | Top 10 products via `product_id` + `[Top 10 Customer Revenue]` (swap measure to product) |
| Bottom | Heat matrix | `product_category` × `zone` → `[Total Revenue]` |

---

## Page 5 — Segments & Recommendations

**Goal:** *Which segments to target next.*

| Slot | Visual | Field / Measure |
|---|---|---|
| Left | Donut | `Customer Value Segment` × count of `user_id` |
| Centre | Column | `Customer Value Segment` × `[Total Revenue]` |
| Right | Table | `customer_name`, `[Total Revenue]`, `[Total Orders]`, `[Average Order Value (AOV)]` — filter by `Customer Rank <= 20` |
| Bottom (text box) | Text | Bulleted list of recommendations (copy-paste from `reports/Business_Report.md`) |

---

## Colour & Typography

- **Primary:** `#F5A623` (marigold) — for KPI accents, positive callouts.
- **Secondary:** `#E94E1B` (saffron) — headline bars.
- **Tertiary:** `#B8336A`, `#6A0572`, `#3D348B`, `#1B998B` — segmentation categories.
- **Background:** `#0d1b2a` for Executive page; `#F7F5F2` (warm off-white) for other pages.
- **Font:** *Segoe UI Semibold* for titles, *Segoe UI* for body. If you want a distinctive look, swap in *DM Sans* or *Poppins* (free Google fonts, install locally).

---

## Interaction Design

- Turn **cross-filtering ON** for all charts on the same page.
- Enable **drill-through** from *Geography → State detail*: right-click any state → *Drill through → State detail page* (add a hidden 6th page for this).
- Add **bookmarks** for "Female only", "Married only", "Zone: Central" so viewers can switch scenarios instantly.

---

## Final polish checklist

- [ ] Theme applied (`diwali_theme.json`).
- [ ] All measures created, `_Measures` table used.
- [ ] `age_group` sort-by-column applied.
- [ ] Tooltips customised (add `[Revenue Share (%)]` everywhere).
- [ ] Titles are business-worded, not column names.
- [ ] Grid alignment: use *Format → Align* to snap visuals.
- [ ] Publish → export as PDF for offline review.
