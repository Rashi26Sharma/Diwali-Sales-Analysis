# Power Query (M) Code

Open **Home → Transform Data → Advanced Editor** and paste the script below. Update the file path on the second line to match your machine.

```m
let
    // 1. Source — update path to where you saved the CSV
    Source = Csv.Document(
        File.Contents("C:\Path\To\Diwali_Sales_PowerBI_Ready.csv"),
        [Delimiter=",", Columns=16, Encoding=65001, QuoteStyle=QuoteStyle.Csv]
    ),

    // 2. Promote headers
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),

    // 3. Set data types
    Typed = Table.TransformColumnTypes(PromotedHeaders, {
        {"user_id", Int64.Type},
        {"customer_name", type text},
        {"product_id", type text},
        {"gender", type text},
        {"age_group", type text},
        {"age", Int64.Type},
        {"marital_status", Int64.Type},
        {"state", type text},
        {"zone", type text},
        {"occupation", type text},
        {"product_category", type text},
        {"orders", Int64.Type},
        {"amount", type number},
        {"marital_status_label", type text},
        {"avg_order_value", type number},
        {"revenue_bucket", type text}
    }),

    // 4. Remove nulls in amount (defensive; already handled upstream)
    NoNullAmount = Table.SelectRows(Typed, each [amount] <> null and [amount] > 0),

    // 5. Remove duplicates (defensive)
    Deduped = Table.Distinct(NoNullAmount),

    // 6. Add sort order for Age Group (so charts render in the right order)
    WithAgeSort = Table.AddColumn(Deduped, "age_group_sort", each
        if [age_group] = "0-17" then 1
        else if [age_group] = "18-25" then 2
        else if [age_group] = "26-35" then 3
        else if [age_group] = "36-45" then 4
        else if [age_group] = "46-50" then 5
        else if [age_group] = "51-55" then 6
        else 7, Int64.Type),

    // 7. Add sort order for Revenue Bucket
    WithBucketSort = Table.AddColumn(WithAgeSort, "revenue_bucket_sort", each
        if [revenue_bucket] = "<5K" then 1
        else if [revenue_bucket] = "5K-10K" then 2
        else if [revenue_bucket] = "10K-15K" then 3
        else if [revenue_bucket] = "15K-20K" then 4
        else 5, Int64.Type),

    // 8. Trim + Clean text columns
    Cleaned = Table.TransformColumns(WithBucketSort, {
        {"customer_name", each Text.Trim(Text.Clean(_)), type text},
        {"state",         each Text.Trim(Text.Clean(_)), type text},
        {"zone",          each Text.Trim(Text.Clean(_)), type text},
        {"occupation",    each Text.Trim(Text.Clean(_)), type text},
        {"product_category", each Text.Trim(Text.Clean(_)), type text}
    })
in
    Cleaned
```

**Model tip:** After loading, select `age_group` → *Column tools → Sort by column → age_group_sort*. Repeat for `revenue_bucket` (sort by `revenue_bucket_sort`). This makes every visual show them in the natural order instead of alphabetical.
