# Power BI Build Guide — Diwali Sales Dashboard

This folder contains everything required to reproduce the Diwali Sales dashboard in **Power BI Desktop** (free — [download here](https://powerbi.microsoft.com/desktop/)).

## What's inside

| File | Purpose |
|---|---|
| `Diwali_Sales_PowerBI_Ready.csv` | Cleaned, Power-BI-ready dataset (11,231 rows) |
| `power_query_M_code.md` | Full Power Query (M) script for import & transform |
| `dax_measures.md` | Every DAX measure used in the dashboard |
| `dashboard_layout.md` | Page-by-page layout, chart types, filter design |
| `diwali_theme.json` | Custom Diwali colour theme — import via View → Themes → Browse |

## Recommended Build Order

1. **Open Power BI Desktop.**
2. **Import the theme:** *View → Themes → Browse for themes* → select `diwali_theme.json`.
3. **Load data:** *Home → Get Data → Text/CSV* → pick `Diwali_Sales_PowerBI_Ready.csv`.
4. **(Optional) Replace the auto Power Query with the version in `power_query_M_code.md`** (Home → Transform Data → Advanced Editor).
5. **Create the calculated columns and measures** listed in `dax_measures.md` (Modeling → New Measure / New Column).
6. **Build the report pages** exactly as described in `dashboard_layout.md`. Suggested pages:
   - **Executive Summary** (KPI cards + overview)
   - **Customer Demographics** (Gender / Age / Marital)
   - **Geography** (Zone + State map)
   - **Products** (Category + Top SKUs)
   - **Segments & Recommendations**
7. **Publish** to Power BI Service (optional) and save as `Diwali_Sales_Dashboard.pbix`.

## Data Model

Single-table star schema (fact only — dimensions are denormalised for portfolio simplicity):

```
Diwali_Sales (fact + attributes)
├── user_id, customer_name           → Customer attributes
├── gender, age, age_group,          → Demographics
│   marital_status_label
├── state, zone                      → Geography
├── occupation                       → Segmentation
├── product_id, product_category     → Product
├── orders, amount, avg_order_value  → Facts
└── revenue_bucket                   → Feature
```

For a more advanced star schema, you can later split out `dim_customer`, `dim_product`, and `dim_geo`, using `user_id`, `product_id` and `state` as the keys.
