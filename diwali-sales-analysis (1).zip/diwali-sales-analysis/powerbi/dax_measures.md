# DAX Measures — Diwali Sales Dashboard

Add these under **Modeling → New Measure**. Group them into a dedicated measures table for cleanliness (recommended: create a blank table called `_Measures` via *Home → Enter Data*, then move each measure into it).

---

## 1. Core KPIs

```DAX
Total Revenue = SUM ( 'Diwali_Sales'[amount] )
```

```DAX
Total Orders = SUM ( 'Diwali_Sales'[orders] )
```

```DAX
Total Transactions = COUNTROWS ( 'Diwali_Sales' )
```

```DAX
Unique Customers = DISTINCTCOUNT ( 'Diwali_Sales'[user_id] )
```

```DAX
Average Ticket Size =
DIVIDE ( [Total Revenue], [Total Transactions] )
```

```DAX
Average Order Value (AOV) =
DIVIDE ( [Total Revenue], [Total Orders] )
```

```DAX
Revenue Per Customer =
DIVIDE ( [Total Revenue], [Unique Customers] )
```

---

## 2. Formatted KPI Labels (for cards)

```DAX
Revenue (Cr) =
"₹ " & FORMAT ( [Total Revenue] / 10000000, "0.00" ) & " Cr"
```

```DAX
AOV Formatted =
"₹ " & FORMAT ( [Average Order Value (AOV)], "#,##0" )
```

---

## 3. Segment-Level Measures

```DAX
Female Revenue =
CALCULATE ( [Total Revenue], 'Diwali_Sales'[gender] = "F" )
```

```DAX
Male Revenue =
CALCULATE ( [Total Revenue], 'Diwali_Sales'[gender] = "M" )
```

```DAX
Female Revenue % =
DIVIDE ( [Female Revenue], [Total Revenue] )
```

```DAX
Married Revenue =
CALCULATE ( [Total Revenue], 'Diwali_Sales'[marital_status_label] = "Married" )
```

```DAX
Married Revenue % =
DIVIDE ( [Married Revenue], [Total Revenue] )
```

---

## 4. Ranking & "Top N" measures

```DAX
State Rank =
RANKX (
    ALL ( 'Diwali_Sales'[state] ),
    [Total Revenue],
    ,
    DESC,
    Dense
)
```

```DAX
Category Rank =
RANKX (
    ALL ( 'Diwali_Sales'[product_category] ),
    [Total Revenue],
    ,
    DESC,
    Dense
)
```

```DAX
Customer Rank =
RANKX (
    ALL ( 'Diwali_Sales'[user_id], 'Diwali_Sales'[customer_name] ),
    [Total Revenue],
    ,
    DESC,
    Dense
)
```

```DAX
Top 10 State Revenue =
IF ( [State Rank] <= 10, [Total Revenue], BLANK () )
```

```DAX
Top 10 Category Revenue =
IF ( [Category Rank] <= 10, [Total Revenue], BLANK () )
```

```DAX
Top 10 Customer Revenue =
IF ( [Customer Rank] <= 10, [Total Revenue], BLANK () )
```

---

## 5. Contribution / Share measures

```DAX
Revenue Share (%) =
DIVIDE (
    [Total Revenue],
    CALCULATE ( [Total Revenue], ALL ( 'Diwali_Sales' ) )
)
```

```DAX
Zone Revenue Share =
DIVIDE (
    [Total Revenue],
    CALCULATE ( [Total Revenue], ALL ( 'Diwali_Sales'[zone] ) )
)
```

---

## 6. Segmentation via calculated column

Create as a **New Column** (not measure) on the fact table:

```DAX
Customer Value Segment =
VAR CustRevenue =
    CALCULATE (
        SUM ( 'Diwali_Sales'[amount] ),
        ALLEXCEPT ( 'Diwali_Sales', 'Diwali_Sales'[user_id] )
    )
RETURN
    SWITCH (
        TRUE (),
        CustRevenue >= 40000, "VIP / Champions",
        CustRevenue >= 20000, "Loyal High-Spenders",
        CustRevenue >= 8000,  "Regulars",
        "Bargain / Low-Value"
    )
```

Use this column as a slicer, legend, or axis on the *Segments & Recommendations* page.

---

## 7. Executive-summary composite measure

```DAX
KPI Executive Text =
"Revenue " & [Revenue (Cr)] &
" · Orders " & FORMAT ( [Total Orders], "#,##0" ) &
" · Customers " & FORMAT ( [Unique Customers], "#,##0" ) &
" · AOV " & [AOV Formatted]
```

Drop this into a *Card* visual at the top of the Executive Summary page for a one-line, board-ready readout.
