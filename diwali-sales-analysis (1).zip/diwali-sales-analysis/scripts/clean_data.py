"""
Diwali Sales Data Cleaning Script
---------------------------------
Reads the raw dataset, performs cleaning, and outputs cleaned files
for both the notebook workflow and Power BI ingestion.
"""

import os
import pandas as pd
import numpy as np

RAW_PATH = os.path.join("data", "raw", "Diwali_Sales_Data.csv")
CLEANED_PATH = os.path.join("data", "cleaned", "Diwali_Sales_Cleaned.csv")
POWERBI_PATH = os.path.join("powerbi", "Diwali_Sales_PowerBI_Ready.csv")


def load_raw(path: str = RAW_PATH) -> pd.DataFrame:
    """Load raw Diwali Sales CSV with the correct encoding."""
    return pd.read_csv(path, encoding="latin-1")


def clean_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """Perform end-to-end cleaning: drop blanks, handle NaN, cast dtypes, add features."""
    # 1. Drop completely blank columns
    df = df.drop(columns=[c for c in ["Status", "unnamed1"] if c in df.columns])

    # 2. Drop rows where Amount is missing (12 rows)
    df = df.dropna(subset=["Amount"]).reset_index(drop=True)

    # 3. Rename columns to snake_case for consistency
    df = df.rename(
        columns={
            "User_ID": "user_id",
            "Cust_name": "customer_name",
            "Product_ID": "product_id",
            "Gender": "gender",
            "Age Group": "age_group",
            "Age": "age",
            "Marital_Status": "marital_status",
            "State": "state",
            "Zone": "zone",
            "Occupation": "occupation",
            "Product_Category": "product_category",
            "Orders": "orders",
            "Amount": "amount",
        }
    )

    # 4. Data type conversion
    df["amount"] = df["amount"].astype("float64").round(2)
    df["orders"] = df["orders"].astype("int64")
    df["age"] = df["age"].astype("int64")
    df["marital_status"] = df["marital_status"].astype("int8")

    # 5. Human-readable marital status
    df["marital_status_label"] = df["marital_status"].map({0: "Single", 1: "Married"})

    # 6. Derived features
    df["avg_order_value"] = (df["amount"] / df["orders"]).round(2)
    df["revenue_bucket"] = pd.cut(
        df["amount"],
        bins=[0, 5000, 10000, 15000, 20000, np.inf],
        labels=["<5K", "5K-10K", "10K-15K", "15K-20K", "20K+"],
    )

    # 7. Remove duplicates (if any)
    df = df.drop_duplicates().reset_index(drop=True)

    return df


def save_cleaned(df: pd.DataFrame) -> None:
    """Write cleaned dataset to both cleaned and powerbi folders."""
    os.makedirs(os.path.dirname(CLEANED_PATH), exist_ok=True)
    os.makedirs(os.path.dirname(POWERBI_PATH), exist_ok=True)
    df.to_csv(CLEANED_PATH, index=False)
    df.to_csv(POWERBI_PATH, index=False)


if __name__ == "__main__":
    raw = load_raw()
    print(f"Raw shape: {raw.shape}")
    cleaned = clean_dataframe(raw)
    print(f"Cleaned shape: {cleaned.shape}")
    print(cleaned.head())
    save_cleaned(cleaned)
    print("Cleaned files written successfully.")
